import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';

interface DatabaseSchema {
  interactions: Array<{ question: string; response: string; timestamp: string }>;
}

const file = 'db.json';
const adapter = new JSONFile<DatabaseSchema>(file);


const defaultData: DatabaseSchema = { interactions: [] };

const db = new Low(adapter, defaultData);

export async function initializeDatabase() {
  await db.read();
  db.data ||= defaultData;
  await db.write();
}

export async function saveInteraction(question: string, response: string) {
  await db.read();
  db.data?.interactions.push({ question, response, timestamp: new Date().toISOString() });
  await db.write();
}

export async function getAllInteractions() {
  await db.read();
  return db.data?.interactions || [];
}

import { task } from "@trigger.dev/sdk/v3"; 
import axios from "axios";
import { saveInteraction } from "./database";

const HUGGINGFACE_API_KEY = "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";

const API_URL = "https://api-inference.huggingface.co/models/gpt2"; 


async function getHuggingFaceResponse(question: string) {
  try {
   
    if (!question || question.trim() === "") {
      throw new Error("Întrebarea nu poate fi goală.");
    }
    const response = await axios.post(
      API_URL,
      { inputs: question },  
      {
        headers: {
          Authorization: `Bearer ${HUGGINGFACE_API_KEY}`,
        },
      }
    );
    
    const generatedText = response.data[0]?.generated_text;

    if (!generatedText) {
      throw new Error("Răspunsul generat este gol.");
    }
    console.log(generatedText);

    return generatedText;
  } catch (error) {
    console.error("Eroare la cererea către Hugging Face API:", error);
    throw error;  
  }
}


export const questionTask = task({
  id: "question-task",
  retry: {
    maxAttempts: 1, 
  },
  run: async (payload: { message?: string }) => {
    try {
     
      if (!payload.message) {
        throw new Error("Mesajul este gol.");
      }

      
      const generatedResponse = await getHuggingFaceResponse(payload.message);

      console.log("Întrebarea trimisă către Hugging Face:", generatedResponse);
      saveInteraction(payload.message, generatedResponse);

      
      return {
        runId: "task-completed", 
        response: generatedResponse,
        timestamp: new Date(),
        role: 'assistant'
      };
    } catch (error) {
     
      console.error("Eroare la interogarea modelului Hugging Face:", error);
      throw error;
    }
  },
});
